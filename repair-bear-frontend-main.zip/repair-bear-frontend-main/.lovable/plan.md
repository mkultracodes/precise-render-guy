

# Hybrid Shatter Effect (Option B + C Combined)

## Problem
The current Option B SVG lines look unrealistic — straight lines radiating from a point resemble a lightning bolt, not cracked glass. Also, the `crack-line-draw` CSS class is never defined, so the line-draw animation isn't even working.

## Approach: Combine B and C
Layer two effects together for a convincing cracked phone screen:

1. **Layer 1 — Geometric shards (Option C)**: ~10 irregular polygon shards defined by `clip-path`, each with a semi-transparent white/gray fill and subtle `box-shadow` borders. Shards shift 1-3px apart using the existing `shard-break` animation, revealing dark gaps between them — this creates the physical "broken glass" structure.

2. **Layer 2 — Crack lines (Option B, improved)**: Instead of straight radial lines, use **jagged polylines** (zigzag paths with 4-6 waypoints each) that follow the shard boundaries. These are thin white SVG strokes that trace realistic fracture paths — not straight lines from a center point, but branching cracks with slight randomness.

3. **Layer 3 — Impact point**: A small frosted/bright spot near the impact area with a radial gradient, simulating the crushed glass at the point of contact.

## Key improvements over current implementation
- Crack paths will be **jagged polylines** (e.g., `M100,140 L95,120 L102,95 L90,60 L85,30 L80,0`) instead of straight lines
- Shards provide the physical depth — glass pieces that have shifted apart
- No concentric circles (those looked artificial)
- Add the missing `crack-line-draw` keyframe to CSS (stroke-dashoffset animation)
- Keep z-20 layering so cracks appear over the "BROKEN PHONE?" text

## Files to change

**`src/components/PhoneAnimation.tsx`** — Rewrite `ShatteredScreen`:
- Add ~10 polygon `div` shards with `clip-path`, white borders via `box-shadow`, and staggered `shard-shift` animations
- Replace straight SVG paths with jagged polylines for crack lines
- Remove concentric circles
- Keep frosted impact point

**`src/index.css`** — Add missing `crack-line-draw` keyframe:
```css
.crack-line-draw {
  stroke-dasharray: 600;
  stroke-dashoffset: 600;
  animation: crack-draw 0.6s ease-out forwards;
}
@keyframes crack-draw {
  to { stroke-dashoffset: 0; }
}
```

